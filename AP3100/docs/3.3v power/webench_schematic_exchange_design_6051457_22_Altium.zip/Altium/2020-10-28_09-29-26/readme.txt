 
 
 
**********************************************************
*************  Important Instructions Follow  ************
**********************************************************
 
All files exported to: Z:\\60\\51\\6051457\\22\Altium\2020-10-28_09-29-26\2020-10-28_09-29-26
 
 
**********************************************************
***************** Schematic Instructions  ****************
**********************************************************

To import your new Schematic into Altium:

1. Unzip the downloaded folder files to a local directory and
Start the Altium program.
2. From the menu select "File"->"Open".
3. Select the file named in the path above ending with ".schdoc"
and "Open" the file.
4. Your Schematic should be viewable within Altium now.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Altium_BrdSch_import.html



**********************************************************
*******************  PCB Instructions  *******************
**********************************************************


To import your new BOARD into Altium:

1. Unzip the downloaded folder files to a local directory
	and Start the Altium program.
2. From the menu select "File"->"Open".
3. Select the file named in the path above ending with ".pcbdoc"
and "Open" the file.
4. Planes will need to be repoured to update the Copper Pour Polygons
	a. Once your board is loaded, select the Tools menu from the
	   top Menu Bar
	b. Scroll to the Polygon Pours item on the Tools Menu.
	c. The Polygon Pours item should expand to show more options
	d. Select Repour All Polygons, this will repour all of the
	   polygons.
5. Your board should be viewable within Altium now.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Altium_BrdSch_import.html

**********************************************************
*******************  LIB Instructions  *******************
**********************************************************

To import your new LIBRARY PARTS into Altium follow these steps:

1. After running the Ultra Librarian export for the first time,
you will need to copy the following files into an area where
they can be accessed for all future translations.  They are script
files that Altium will need to be able to find.
	a. UL_Form.dfm
	b. UL_Form.pas
	c. UL_Import.pas
	d. UL_Import.prjScr
2. The above script file will need to be run from within Altium.
This can be done by going to File, Open and selecting the
UL_Import.PrjScr file stored above.
3. Select the "DXP" dropdown menu in the top-left corner runfrom
the drop down menu and select "Run Script". Select "UL_Form.pas"
and click "OK"
4. When the script is run, it will ask you for the file name of the
Ultra Librarian file to run. Click "File...", select the latest file
produced with a date code (for instance 2010-02-17_23-12-34.txt), and
click "Start Import".
5. The script will open a new Integraged Library project and import
the Ultra Librarian data into it.  When complete a message box
will pop up saying that import is done.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Altium_import.html

For a video tutorial, please visit:
http://youtu.be/pih50yx9HYU

**********************************************************
**********************************************************
**********************************************************
 
 
Padstack "RX86p61Y314p96D0T" renamed to "RX86p61Y314p96D0"
Symbol "WB_TPS54A24_Rpg_Vdc_block" renamed to "WB_TPS54A24_Rpg_"
Symbol "WB_SOURCE_RESISTOR" renamed to "WB_SOURCE_RESIST"
Symbol "WB_PRIMITIVE_BATTERY" renamed to "WB_PRIMITIVE_BAT"
Symbol "WB_RPG_BLOCK_TPS54A24" renamed to "WB_RPG_BLOCK_TPS"
Symbol "WB_TPS54A24_VSYNC" renamed to "WB_TPS54A24_VSYN"
Symbol "WB_PRIM_PULSE_VOLTAGE_SOURCE" renamed to "WB_PRIM_PULSE_VO"
Symbol "WB_TPS54A24_COUTX_BLOCK" renamed to "WB_TPS54A24_COUT"
Symbol "WB_TPS54A24_UVLO_EN_BLOCK" renamed to "WB_TPS54A24_UVLO"
Symbol "WB_TPS54A24_FBDIVIDER" renamed to "WB_TPS54A24_FBDI"
Symbol "WB_TPS54A24_FBSHORT" renamed to "WB_TPS54A24_FBSH"
Symbol "WB_ZERO_VOLT_SOURCE" renamed to "WB_ZERO_VOLT_SOU"
Symbol "WB_TPS54A24_CCOMP3_BLOCK" renamed to "WB_TPS54A24_CCOM"
Symbol "WB_STARTUP_VOLTAGE_SOURCE" renamed to "WB_STARTUP_VOLTA"
Symbol "WB_PRIM_STARTUP_VOLTAGE_SOURCE" renamed to "WB_PRIM_STARTUP_"
Symbol "WB_PWL_VOLTAGE_SOURCE" renamed to "WB_PWL_VOLTAGE_S"
Symbol "WB_PRIM_PWL_VOLTAGE_SOURCE" renamed to "WB_PRIM_PWL_VOLT"
Symbol "WB_PWL_CURRENT_LOAD" renamed to "WB_PWL_CURRENT_L"
Component "WB_GND" renamed to "WB_GND"
Component "SRN8040-R50Y" renamed to "SRN8040-R50Y"
Component "GRM1885C1H182JA01J" renamed to "GRM1885C1H182JA0"
Component "CRCW040210K0FKED" renamed to "CRCW040210K0FKED"
Component "CRCW0402100KFKED" renamed to "CRCW0402100KFKED"
Component "C0805C106K8PACTU" renamed to "C0805C106K8PACTU"
Component "TPS54A24RTWR" renamed to "TPS54A24RTWR"
Component "GRM31CR60J107ME39L" renamed to "GRM31CR60J107ME3"
Component "C1608X7R1V105K080AC" renamed to "C1608X7R1V105K08"
Component "RT0805BRD0727K1L" renamed to "RT0805BRD0727K1L"
Component "CRCW04026K04FKED" renamed to "CRCW04026K04FKED"
Component "GRM155R61A103KA01D" renamed to "GRM155R61A103KA0"
Component "CL05C130JB5NNNC" renamed to "CL05C130JB5NNNC"
Component "GRM188R71H104KA93D" renamed to "GRM188R71H104KA9"
Component "GRM155R71C104KA88D" renamed to "GRM155R71C104KA8"
Component "CRCW040248K7FKED" renamed to "CRCW040248K7FKED"
Component "WB_BATTERY" renamed to "WB_BATTERY"
Component "WB_CURRENT_LOAD" renamed to "WB_CURRENT_LOAD"
The Symbol WB_CONTINUATION was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CONTINUATION was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CONTINUATION was missing a Value attribute, a value was created for the symbol.
The Symbol WB_TPS54A24_Rpg_ was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_TPS54A24_Rpg_ was missing a Type attribute, a type was created for the symbol.
The Symbol WB_TPS54A24_Rpg_ was missing a Value attribute, a value was created for the symbol.
The Symbol WB_BLOCK_IO was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Type attribute, a type was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Value attribute, a value was created for the symbol.
The Symbol WB_SOURCE_RESIST was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_SOURCE_RESIST was missing a Type attribute, a type was created for the symbol.
The Symbol WB_SOURCE_RESIST was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIMITIVE_BAT was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIMITIVE_BAT was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIMITIVE_BAT was missing a Value attribute, a value was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_RPG_BLOCK_TPS was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_RPG_BLOCK_TPS was missing a Type attribute, a type was created for the symbol.
The Symbol WB_RPG_BLOCK_TPS was missing a Value attribute, a value was created for the symbol.
The Symbol WB_TPS54A24_VSYN was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_TPS54A24_VSYN was missing a Type attribute, a type was created for the symbol.
The Symbol WB_TPS54A24_VSYN was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIM_PULSE_VO was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIM_PULSE_VO was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIM_PULSE_VO was missing a Value attribute, a value was created for the symbol.
The Symbol WB_TPS54A24RTW was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_TPS54A24RTW was missing a Type attribute, a type was created for the symbol.
The Symbol WB_TPS54A24RTW was missing a Value attribute, a value was created for the symbol.
The Symbol WB_TPS54A24_COUT was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_TPS54A24_COUT was missing a Type attribute, a type was created for the symbol.
The Symbol WB_TPS54A24_COUT was missing a Value attribute, a value was created for the symbol.
The Symbol WB_TPS54A24_UVLO was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_TPS54A24_UVLO was missing a Type attribute, a type was created for the symbol.
The Symbol WB_TPS54A24_UVLO was missing a Value attribute, a value was created for the symbol.
The Symbol WB_TPS54A24_FBDI was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_TPS54A24_FBDI was missing a Type attribute, a type was created for the symbol.
The Symbol WB_TPS54A24_FBDI was missing a Value attribute, a value was created for the symbol.
The Symbol WB_TPS54A24_FBSH was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_TPS54A24_FBSH was missing a Type attribute, a type was created for the symbol.
The Symbol WB_TPS54A24_FBSH was missing a Value attribute, a value was created for the symbol.
The Symbol WB_ZERO_VOLT_SOU was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_ZERO_VOLT_SOU was missing a Type attribute, a type was created for the symbol.
The Symbol WB_ZERO_VOLT_SOU was missing a Value attribute, a value was created for the symbol.
The Symbol WB_TPS54A24_CCOM was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_TPS54A24_CCOM was missing a Type attribute, a type was created for the symbol.
The Symbol WB_TPS54A24_CCOM was missing a Value attribute, a value was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a Type attribute, a type was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a Value attribute, a value was created for the symbol.
The Symbol WB_STARTUP_VOLTA was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_STARTUP_VOLTA was missing a Type attribute, a type was created for the symbol.
The Symbol WB_STARTUP_VOLTA was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIM_STARTUP_ was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIM_STARTUP_ was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIM_STARTUP_ was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PWL_VOLTAGE_S was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PWL_VOLTAGE_S was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PWL_VOLTAGE_S was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIM_PWL_VOLT was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIM_PWL_VOLT was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIM_PWL_VOLT was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PWL_CURRENT_L was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PWL_CURRENT_L was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PWL_CURRENT_L was missing a Value attribute, a value was created for the symbol.


Ultra Librarian Gold 8.1.204 Process Report


Message - Symbol "WB_CAPACITOR" has as multiple attributes named "TYPE".
One of the attributes was renamed to "TYPE_2".
Message - Component "SRN8040-R50Y" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SRN8040-R50Y" attribute "L" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SRN8040-R50Y" attribute "DCR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SRN8040-R50Y" attribute "IDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM1885C1H182JA0" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM1885C1H182JA0" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM1885C1H182JA0" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM1885C1H182JA0" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM1885C1H182JA0" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040210K0FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040210K0FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040210K0FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW0402100KFKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW0402100KFKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW0402100KFKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0805C106K8PACTU" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0805C106K8PACTU" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0805C106K8PACTU" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0805C106K8PACTU" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM31CR60J107ME3" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM31CR60J107ME3" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM31CR60J107ME3" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM31CR60J107ME3" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X7R1V105K08" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X7R1V105K08" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X7R1V105K08" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X7R1V105K08" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RT0805BRD0727K1L" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RT0805BRD0727K1L" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RT0805BRD0727K1L" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04026K04FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04026K04FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04026K04FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R61A103KA0" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R61A103KA0" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R61A103KA0" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R61A103KA0" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL05C130JB5NNNC" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL05C130JB5NNNC" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL05C130JB5NNNC" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL05C130JB5NNNC" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL05C130JB5NNNC" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM188R71H104KA9" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM188R71H104KA9" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM188R71H104KA9" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM188R71H104KA9" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71C104KA8" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71C104KA8" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71C104KA8" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71C104KA8" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040248K7FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040248K7FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040248K7FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Pattern "RTW0024B", Attribute "RefDes" is a duplicate Attribute and will be deleted.

TextStyle count:  24
Padstack count:   7
Pattern count:    6
Symbol count:     30
Component count:  18

Export

Footprint "0603" has no layer data mapped and will be skipped.
Component "GRM1885C1H182JA0" requires footprint "0603" and will be skipped.
Component "C1608X7R1V105K08" requires footprint "0603" and will be skipped.
Component "GRM188R71H104KA9" requires footprint "0603" and will be skipped.
Footprint "0402" has no layer data mapped and will be skipped.
Component "CRCW040210K0FKED" requires footprint "0402" and will be skipped.
Component "CRCW0402100KFKED" requires footprint "0402" and will be skipped.
Component "CRCW04026K04FKED" requires footprint "0402" and will be skipped.
Component "GRM155R61A103KA0" requires footprint "0402" and will be skipped.
Component "CL05C130JB5NNNC" requires footprint "0402" and will be skipped.
Component "GRM155R71C104KA8" requires footprint "0402" and will be skipped.
Component "CRCW040248K7FKED" requires footprint "0402" and will be skipped.
Footprint "0805" has no layer data mapped and will be skipped.
Component "C0805C106K8PACTU" requires footprint "0805" and will be skipped.
Component "RT0805BRD0727K1L" requires footprint "0805" and will be skipped.
Warning: Symbol "WB_INDUCTOR" attribute "L" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "DCR" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "IDC" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "PN" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "DEV" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "VAL" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "TOL" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "RefDes2" references missing text style ""
Warning: Symbol "TPS54A24RTW" attribute "VAL" references missing text style ""
Warning: Symbol "TPS54A24RTW" attribute "DEV" references missing text style ""
Warning: Symbol "TPS54A24RTW" attribute "PN" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "Cap" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "ESR" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "IRMS" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "VDC" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "PN" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "DEV" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "VAL" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "TOL" references missing text style ""
Warning: Symbol "WB_CAPACITOR" attribute "RefDes2" references missing text style ""
